// Comentário de linha

/*Comentário de Bloco
Bananinha!*/

//Testando console.log

// console.log ('Olá Mundo !')
// console.log('Boaa noite Joy!')

//Testando Prompt

// const serie = prompt('Digite uma série')

// let nomeUsuario = prompt('Digite o nome do usuário')
// nomeUsuario = prompt ('Digite novamente o nome do usuário')
// console.log(nomeUsuario)

//Declarando Variáveis

// let idade = 27
// const nome = 'Fayra Miranda'

// console.log(idade)
// console.log(nome)

// const nomeDoUsuario = 'Lais'

// const primeiroNumero = 29
// const segundoNumero = 10
// const terceiroNumero = 5

// console.log(primeiroNumero) // 29
// console.log(segundoNumero) //10
// console.log(terceiroNumero) //5

// console.log ("O primeiro número é", primeiroNumero, ", o segundo número é ", segundoNumero, ", o terceiro número é", terceiroNumero)

//Números

// let temporadas = 12
// let temperatura = -20
// let numero = 34566776

//Strings 

// const artista = 'Falamansa'
// let tempoDeBanda = "21"

// const primeiroNumero = true
// const segundoNumero = false

// let numeroBooleanoTrue = true
// let numeroBooleanoFalse = false

// console.log (numeroBooleanoTrue)
// console.log(numeroBooleanoFalse)

//Exemplo 1

// const primeiroNome = "Fayra" //string
// const sobreNome = "Tolentino Miranda" //string
// let idade = 27 //number
// const ehEstudante = false //boolean

// console.log("O nome é", primeiroNome, " , o sobrenome é", sobreNome, " , a idade é", idade, " ,é ou não estudante", ehEstudante)

// console.log("O nome é", primeiroNome, ",", "o sobrenome é", sobreNome, ",","a idade é", idade, "," ,"é ou não estudante", ehEstudante)

//TypeOf

// console.log(typeof primeiroNome)
// console.log(typeof sobreNome)
// console.log(typeof idade)
// console.log(typeof ehEstudante)


//Undefined

// let fruta
// let fruta = 'Bananinha'
// console.log(typeof fruta)


//Undefined x Null

// let variavelUndefined
// let variavelNull = null 

// console.log(typeof variavelUndefined)
// console.log (typeof variavelNull)

//Exemplo 2

// Peça nome do seu usuário através do prompt e guarde em uma variável

// let nomeUsuario = prompt("Digite o seu nome!")

// Peça a idade do seu usuário através do prompt e guarde em uma variável

// let idadeDoUsuario = prompt ("Digite a sua idade")

//Veja qual é o tipo das variáveis de nome e idade

// console.log(typeof nomeUsuario)
// console.log(typeof idadeDoUsuario)

//Conversão de tipos

// const idade = 27
// console.log(typeof idade)

// const idadeTexto = idade.toString()
// console.log(typeof idadeTexto)

//Converter string para  numero

// const stringParaNumero = Number(idadeTexto)
// console.log(typeof stringParaNumero)
